#Functionalities to add
1) Job Posting
2) Candidate Referral
3) Interview Scheduling
4) Employee Leave -> Date of Exit [Terminate, Resigned, Retired]
